﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5___ADGM_1369923_ej2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ejercicio 2");
            Console.WriteLine("ingrese un número del 1 al 7");
            string num = Console.ReadLine();
            int nume = int.Parse(num);
            if (nume == 1)
            {
                Console.WriteLine("DIA: Lunes");
                Console.ReadKey();
            }
            if (nume == 2)
            {
                Console.WriteLine("DIA: Martes");
                Console.ReadKey();
            }
            if (nume == 3)
            {
                Console.WriteLine("DIA: Miercoles");
                Console.ReadKey();
            }
            if (nume == 4)
            {
                Console.WriteLine("DIA: Jueves");
                Console.ReadKey();
            }
            if (nume == 5)
            {
                Console.WriteLine("DIA: Viernes");
                Console.ReadKey();
            }
            if (nume == 6)
            {
                Console.WriteLine("DIA: Sabado");
                Console.ReadKey();
            }
            if (nume == 7)
            {
                Console.WriteLine("DIA: Domingo");
                Console.ReadKey();
            }
            if (nume <= 0)
            {
                Console.WriteLine("ese dia no existe");
                Console.ReadKey();
            }
            if (nume > 7)
            {
                Console.WriteLine("ese dia no existe");
                Console.ReadKey();
            }
        }
    }
}

