﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5___ADGM_1369923
{
    internal class Program
    { 

        static void Main(string[] args)
    {
        Console.WriteLine("ejercicio 1");
        Console.WriteLine("por favor ingrese cualquier nùmero entero real");
            string num = Console.ReadLine();  
        int nume = int.Parse(num);
        if (nume > 0)
        {
            Console.WriteLine("su nùmero es positivo");
            Console.ReadKey();
        }
            if (nume == 0)
            {
                Console.WriteLine("su numero es cero");
                Console.ReadKey();
            }
            if(nume < 0)
        { Console.WriteLine("su número es negativo");
            Console.ReadKey();
        }
  

    }
}
}