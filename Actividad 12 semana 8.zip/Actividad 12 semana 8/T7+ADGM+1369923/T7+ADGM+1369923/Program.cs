﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T7_ADGM_1369923
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Tarea No. 07 - <número de carnet>";
            int x, a, n;

            Console.Write("Ingrese el valor de x: ");
            while (!int.TryParse(Console.ReadLine(), out x) || x <= 0)
                Console.Write("Valor no válido. Ingrese un número entero mayor que 0: ");

            Console.Write("Ingrese el valor de a: ");
            while (!int.TryParse(Console.ReadLine(), out a))
                Console.Write("Valor no válido. Ingrese un número entero: ");

            Console.Write("Ingrese el valor de n: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
                Console.Write("Valor no válido. Ingrese un número entero mayor que 0: ");
            Console.WriteLine("Serie a: " + CalculateSeriesA(n));
            Console.WriteLine("Serie b: " + CalculateSeriesB(n));
            Console.WriteLine("Serie c: " + CalculateSeriesC(x, a, n));

            Console.ReadLine(); 
        }

        static double CalculateSeriesA(int N)
        {
            double result = 0;

            for (int i = 1; i <= N; i++)
            {
                result += 1.0 / i;
            }

            return result;
        }
        static double CalculateSeriesB(int N)
        {
            double result = 0;

            for (int i = 1; i <= N; i++)
            {
                result += 1.0 / Math.Pow(2, i);
            }

            return result;
        }
        static double CalculateSeriesC(int x, int a, int n)
        {
            double result = 0;

            for (int k = 0; k <= n; k++)
            {
                result += Math.Pow(x, k) / (Math.Pow(a, n - k));
            }
            return result;
        }
    }
}
