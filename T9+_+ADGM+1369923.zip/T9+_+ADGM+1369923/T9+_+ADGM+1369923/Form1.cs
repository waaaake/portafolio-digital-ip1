﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
class Motocicleta
{
    private int modelo;
    private double precio;
    private string marca;
    private double iva;

    public Motocicleta()
    {
        modelo = 2019;
        precio = 1000;
        marca = "";
        iva = 0.12;
    }

    public string MostrarDatos()
    {
        return $"Modelo: {modelo}\nPrecio: {precio:C}\nMarca: {marca}\nIVA: {iva:P}";
    }

    public void DefinirPrecio(double nuevoPrecio)
    {
        precio = nuevoPrecio;
    }

    public void DefinirIva(double nuevoIva)
    {
        if (nuevoIva >= 0.01 && nuevoIva <= 0.99)
            iva = nuevoIva;
        else
            Console.WriteLine("El valor del IVA debe estar entre 0.01 y 0.99.");
    }

    public double PrecioSinIva()
    {
        return precio;
    }

    public double PrecioConIva()
    {
        return precio * (1 + iva);
    }

    public double DevolverIva()
    {
        return precio * iva;
    }
}
namespace T9___ADGM_1369923
{
    public partial class Form1 : Form
    {
        private Motocicleta objMotocicleta;

        public Form1()
        {
            InitializeComponent();
            objMotocicleta = new Motocicleta();
        }

        private void buttonMostrarDatos_Click(object sender, EventArgs e)
        {
            MessageBox.Show(objMotocicleta.MostrarDatos(), "Datos de la Motocicleta");
        }

        private void buttonPrecioSinIVA_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Precio sin IVA: " + objMotocicleta.PrecioSinIva().ToString("C"), "Precio sin IVA");
        }

        private void buttonPrecioConIVA_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Precio con IVA: " + objMotocicleta.PrecioConIva().ToString("C"), "Precio con IVA");
        }

        private void buttonMontoIVA_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Monto del IVA: " + objMotocicleta.DevolverIva().ToString("C"), "Monto del IVA");
        }

        private void buttonActualizar_Click(object sender, EventArgs e)
        {
            double nuevoPrecio, nuevoIva;

            if (double.TryParse(textBoxNuevoPrecio.Text, out nuevoPrecio))
            {
                objMotocicleta.DefinirPrecio(nuevoPrecio);
            }
            else
            {
                MessageBox.Show("Ingrese un precio válido.", "Error");
                return;
            }

            if (double.TryParse(textBoxNuevoIva.Text, out nuevoIva))
            {
                objMotocicleta.DefinirIva(nuevoIva);
            }
            else
            {
                MessageBox.Show("Ingrese un valor de IVA válido (entre 0.01 y 0.99).", "Error");
                return;
            }

            MessageBox.Show("Precio e IVA actualizados correctamente.", "Actualización Exitosa");
        }
    }
}