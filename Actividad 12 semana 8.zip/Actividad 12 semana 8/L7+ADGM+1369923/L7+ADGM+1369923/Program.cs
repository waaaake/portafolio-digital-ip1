﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L7_ADGM_1369923
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Laboratorio No. 07 - 1369923");
            Console.Write("Ingrese un número entero mayor que 0: ");
            string userInput = Console.ReadLine();

            try
            {
                int N = int.Parse(userInput);
                Console.WriteLine("Serie de Fibonacci hasta el término {0}:", N);
                DisplayFibonacciSeries(N);
            }
            catch (FormatException)
            {
                Console.WriteLine("La entrada no es un número entero válido.");
            }

            Console.ReadLine(); 
        }
        static void DisplayFibonacciSeries(int N)
        {
            int a = 0, b = 1;
            Console.Write("{0} {1}", a, b);

            while (N - 2 > 0)
            {
                int c = a + b;
                Console.Write(" {0}", c);
                a = b;
                b = c;
                N--;
            }

            Console.WriteLine();
        }
    }
}
