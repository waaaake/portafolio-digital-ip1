﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Mi segundo programa");
Console.ReadKey();
Console.WriteLine("Ingrese los siguientes datos");
Console.WriteLine("Nombre:");
String Nombre = Console.ReadLine();
Console.WriteLine("Edad:");
String Edad = Console.ReadLine();
Console.WriteLine("Carrera:");
String Carrera = Console.ReadLine();
Console.WriteLine("Carnè:");
String Carnè = Console.ReadLine();
Console.WriteLine("Soy " + Nombre + ", tengo " + Edad + " años y estudio la carrera de " + Carrera + " y mi nùmero de carnè es: " + Carnè);
Console.ReadKey();