﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {        
        Console.WriteLine("Ejercicio 1: Operaciones aritméticas");

            Console.Write("Ingrese el primer número: ");
            double num1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese el segundo número: ");
            double num2 = Convert.ToDouble(Console.ReadLine());
            double sum = num1 + num2;
            double rest = num1 - num2;
            double multi = num1 * num2;
            double div = num1 / num2;
            double divEntera = (int)num1 / (int)num2; 
            double modulo = num1 % num2;

            Console.WriteLine($"{num1} + {num2} = {sum}");
            Console.WriteLine($"{num1} - {num2} = {rest}");
            Console.WriteLine($"{num1} * {num2} = {multi}");
            Console.WriteLine($"{num1} / {num2} = {div}");
            Console.WriteLine($"{num1} div {num2} = {divEntera}");
            Console.WriteLine($"{num1} mod {num2} = {modulo}");

            Console.WriteLine("Ejercicio 2: Operaciones booleanas");

            bool mayor = num1 > num2;
            bool menor = num1 < num2;
            bool igual = num1 == num2;

            Console.WriteLine($"{num1} > {num2} = {mayor}");
            Console.WriteLine($"{num1} < {num2} = {menor}");
            Console.WriteLine($"{num1} == {num2} = {igua}");

            Console.WriteLine("Ejercicio 3: Jerarquía de operaciones");

            Console.Write("Ingrese el primer número (a): ");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese el segundo número (b): ");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese el tercer número (c): ");
            double c = Convert.ToDouble(Console.ReadLine());

            double expresion1 = a * b + c;
            double expresion2 = a * (b + c);
            double expresion3 = a / (b * c);
            double expresion4 = 3 * a + 2 * b / Math.Pow(c, 2.0 / 3.0);

            Console.WriteLine($"a * b + c = {expresion1}");
            Console.WriteLine($"a * (b + c) = {expresion2}");
            Console.WriteLine($"a / (b * c) = {expresion3}");
            Console.WriteLine($"3a + 2b / c^(2/3) = {expresion4}");

            double discriminante = Math.Pow(b, 2) - 4 * a * c;

            if (discriminante < 0)
            {
                Console.WriteLine("Error: El discriminante es negativo, la expresión cuadrática no tiene soluciones reales.");
            }
            else
            {
                double x1 = (-b + Math.Sqrt(discriminante)) / (2 * a);
                double x2 = (-b - Math.Sqrt(discriminante)) / (2 * a);

                Console.WriteLine("Expresión cuadrática:");
                Console.WriteLine($"x1 = {x1}");
                Console.WriteLine($"x2 = {x2}");
            }
        }
    }
}

