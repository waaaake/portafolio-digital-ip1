﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T4___ADGM_1369923
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese un número: ");
            double numero = Convert.ToDouble(Console.ReadLine());

            int billete100 = (int)(numero / 100);
            int billete50 = (int)((numero % 100) / 50);
            int billete20 = (int)(((numero % 100) % 50) / 20);
            int billete10 = (int)((((numero % 100) % 50) % 20) / 10);
            int billete5 = (int)(((((numero % 100) % 50) % 20) % 10) / 5);
            int billete1 = (int)((((((numero % 100) % 50) % 20) % 10) % 5) / 1);

            int centavos25 = (int)((((((numero % 100) % 50) % 20) % 10) % 5) % 1 / 0.25);
            int centavo1 = (int)((((((((numero % 100) % 50) % 20) % 10) % 5) % 1) % 0.25) / 0.01);

            Console.WriteLine($"{billete100} de Q 100");
            Console.WriteLine($"{billete50} de Q 50");
            Console.WriteLine($"{billete20} de Q 20");
            Console.WriteLine($"{billete10} de Q 10");
            Console.WriteLine($"{billete5} de Q 5");
            Console.WriteLine($"{billete1} de Q 1");
            Console.WriteLine($"{centavos25} de 25 centavos");
            Console.WriteLine($"{centavo1} de 1 centavo");
        }
    }
}
